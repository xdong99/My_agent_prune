import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.stdout.reconfigure(encoding='utf-8')

import asyncio
import argparse
import random
from pathlib import Path
from typing import Union, Literal, List

import numpy as np
import pandas as pd
import torch

from AgentPrune.graph.graph import Graph
from dataset.mmlu_dataset import MMLUDataset
from dataset.MMLU.download import download
from AgentPrune.utils.const import AgentPrune_ROOT

from experiments.embedding_mmlu import select_mmlu_representatives
from experiments.train_mmlu_eki import eki_metrics_per_task_one_step


def parse_args():
    parser = argparse.ArgumentParser(description="Ensemble-size sensitivity test for EKI task ranking on MMLU.")

    parser.add_argument(
        '--mode',
        type=str,
        default='FullConnected',
        choices=[
            'DirectAnswer', 'FullConnected', 'Random', 'Chain', 'Debate', 'Layered', 'Star', 'Mesh',
            'FakeFullConnected', 'FakeRandom', 'FakeChain', 'FakeStar', 'FakeMesh', 'FakeAGRandom', 'FakeAGFull'
        ],
        help="Mode of operation."
    )
    parser.add_argument('--llm_name', type=str, default='gpt-4.1-nano')
    parser.add_argument('--domain', type=str, default='mmlu')
    parser.add_argument('--decision_method', type=str, default='FinalRefer')

    parser.add_argument('--agent_names', nargs='+', type=str, default=['AnalyzeAgent'])
    parser.add_argument('--agent_nums', nargs='+', type=int, default=[5])

    parser.add_argument('--optimized_spatial', action='store_true')
    parser.add_argument('--optimized_temporal', action='store_true')

    parser.add_argument('--split', type=str, default='test')
    parser.add_argument('--rep_sample_n', type=int, default=1000)
    parser.add_argument('--rep_budget', type=int, default=50)

    parser.add_argument('--global_seed', type=int, default=2026)
    parser.add_argument('--num_pools', type=int, default=3)
    parser.add_argument('--num_ensemble_trials', type=int, default=3)

    parser.add_argument('--num_rounds', type=int, default=1)
    parser.add_argument('--prior_std', type=float, default=2.0)
    parser.add_argument('--obs_noise', type=float, default=0.1)
    parser.add_argument('--damping', type=float, default=0.7)
    parser.add_argument('--max_concurrency', type=int, default=8)

    parser.add_argument('--output_dir', type=str, default='outputs/eki_size_sensitivity')

    args = parser.parse_args()

    if len(args.agent_names) != len(args.agent_nums):
        parser.error("The number of agent names must match the number of agent counts.")

    return args


def set_all_seeds(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


def derive_pool_seed(global_seed: int, pool_id: int) -> int:
    return global_seed + 1000 * pool_id + 17


def derive_metric_seed(global_seed: int, pool_id: int, ensemble_size: int, ensemble_trial: int) -> int:
    return global_seed + 100000 * pool_id + 1000 * ensemble_size + 37 * ensemble_trial + 29


def get_kwargs(
    mode: Union[
        Literal['DirectAnswer'], Literal['FullConnected'], Literal['Random'], Literal['Chain'],
        Literal['Debate'], Literal['Layered'], Literal['Star'], Literal['Mesh'],
        Literal['FakeFullConnected'], Literal['FakeRandom'], Literal['FakeChain'],
        Literal['FakeStar'], Literal['FakeMesh'], Literal['FakeAGRandom'], Literal['FakeAGFull']
    ],
    N: int
):
    initial_spatial_probability: float = 0.5
    fixed_spatial_masks: List[List[int]] = None
    initial_temporal_probability: float = 0.5
    fixed_temporal_masks: List[List[int]] = None
    node_kwargs = None

    def generate_layered_graph(N, layer_num=2):
        adj_matrix = [[0] * N for _ in range(N)]
        base_size = N // layer_num
        remainder = N % layer_num
        layers = []
        for i in range(layer_num):
            size = base_size + (1 if i < remainder else 0)
            layers.extend([i] * size)
        random.shuffle(layers)
        for i in range(N):
            current_layer = layers[i]
            for j in range(N):
                if layers[j] == current_layer + 1:
                    adj_matrix[i][j] = 1
        return adj_matrix

    def generate_mesh_graph(N):
        adj_matrix = [[0] * N for _ in range(N)]
        for i in range(0, N):
            for j in range(i + 1, N):
                adj_matrix[i][j] = 1
        return adj_matrix

    def generate_star_graph(N):
        adj_matrix = [[0] * N for _ in range(N)]
        for i in range(1, N):
            adj_matrix[0][i] = 1
        return adj_matrix

    if mode == 'DirectAnswer':
        fixed_spatial_masks = [[0]]
        fixed_temporal_masks = [[0]]
        node_kwargs = [{'role': 'Normal'}]
    elif mode in ['FullConnected', 'FakeFullConnected', 'FakeAGFull']:
        fixed_spatial_masks = [[1 if i != j else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode in ['Random', 'FakeRandom', 'FakeAGRandom']:
        fixed_spatial_masks = [[random.randint(0, 1) if i != j else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[random.randint(0, 1) for _ in range(N)] for _ in range(N)]
    elif mode in ['Chain', 'FakeChain']:
        fixed_spatial_masks = [[1 if i == j + 1 else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[1 if i == 0 and j == N - 1 else 0 for i in range(N)] for j in range(N)]
    elif mode == 'Debate':
        fixed_spatial_masks = [[0 for _ in range(N)] for _ in range(N)]
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode == 'Layered':
        fixed_spatial_masks = generate_layered_graph(N)
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode in ['Mesh', 'FakeMesh']:
        fixed_spatial_masks = generate_mesh_graph(N)
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode in ['Star', 'FakeStar']:
        fixed_spatial_masks = generate_star_graph(N)
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]

    if 'Fake' in mode and 'AG' not in mode:
        node_kwargs = [{'role': 'Fake'} if i % 2 == N % 2 else {'role': 'Normal'} for i in range(N)]
    elif 'Fake' in mode and 'AG' in mode:
        node_kwargs = [{'role': 'Fake'} if i % 2 == N % 2 else {'role': None} for i in range(N)]

    return {
        "initial_spatial_probability": initial_spatial_probability,
        "fixed_spatial_masks": fixed_spatial_masks,
        "initial_temporal_probability": initial_temporal_probability,
        "fixed_temporal_masks": fixed_temporal_masks,
        "node_kwargs": node_kwargs,
    }


def build_graph(args):
    agent_names = [name for name, num in zip(args.agent_names, args.agent_nums) for _ in range(num)]
    kwargs = get_kwargs(args.mode, len(agent_names))

    graph = Graph(
        domain=args.domain,
        llm_name=args.llm_name,
        agent_names=agent_names,
        decision_method=args.decision_method,
        optimized_spatial=args.optimized_spatial,
        optimized_temporal=args.optimized_temporal,
        **kwargs
    )
    return graph


def parse_top_list(text: str):
    if pd.isna(text) or text == "":
        return []
    return [int(x) for x in str(text).split(',')]


def compute_overlap_tables(summary_df: pd.DataFrame, metric_name: str = 'kl', topk: int = 10):
    rows = []
    key = f'top{topk}_{metric_name}'

    grouped = summary_df.groupby(['pool_id', 'ensemble_trial'])
    for (pool_id, ensemble_trial), subdf in grouped:
        subdf = subdf.sort_values('ensemble_size')
        size_to_top = {int(row['ensemble_size']): set(parse_top_list(row[key])) for _, row in subdf.iterrows()}
        sizes = sorted(size_to_top.keys())

        #for i in range(len(sizes)):
        #    for j in range(i + 1, len(sizes)):
        #        s1, s2 = sizes[i], sizes[j]
        #        overlap_count = len(size_to_top[s1] & size_to_top[s2])
        #        rows.append({
        #            'pool_id': pool_id,
        #            'ensemble_trial': ensemble_trial,
        #            'size_1': s1,
        #            'size_2': s2,
        #            'topk': topk,
        #            'metric': metric_name,
        #            'overlap_count': overlap_count,
        #            'overlap_ratio': overlap_count / topk,
        #        })

        baseline_size = 20
        if baseline_size not in size_to_top:
            continue

        for s in sizes:
            if s == baseline_size:
                continue

            overlap_count = len(size_to_top[s] & size_to_top[baseline_size])
            rows.append({
                'pool_id': pool_id,
                'ensemble_trial': ensemble_trial,
                'size_1': s,
                'size_2': baseline_size,
                'topk': topk,
                'metric': metric_name,
                'overlap_count': overlap_count,
                'overlap_ratio': overlap_count / topk,
            })



    pairwise_df = pd.DataFrame(rows)

    agg_df = (
        pairwise_df
        .groupby(['size_1', 'size_2', 'metric', 'topk'], as_index=False)
        .agg(
            overlap_count_mean=('overlap_count', 'mean'),
            overlap_count_std=('overlap_count', 'std'),
            overlap_ratio_mean=('overlap_ratio', 'mean'),
            overlap_ratio_std=('overlap_ratio', 'std'),
        )
    )

    return pairwise_df, agg_df

def append_df_to_csv(df: pd.DataFrame, csv_path: Path):
    write_header = not csv_path.exists()
    df.to_csv(csv_path, mode='a', header=write_header, index=False)


def append_dict_to_csv(row_dict: dict, csv_path: Path):
    df = pd.DataFrame([row_dict])
    write_header = not csv_path.exists()
    df.to_csv(csv_path, mode='a', header=write_header, index=False)

async def run_experiment():
    args = parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    per_task_csv = output_dir / 'eki_size_sensitivity_per_task.csv'
    summary_csv = output_dir / 'eki_size_sensitivity_summary.csv'

    # 每次重新运行时，从头开始写
    if per_task_csv.exists():
        per_task_csv.unlink()
    if summary_csv.exists():
        summary_csv.unlink()

    download()
    dataset = MMLUDataset(args.split)

    ensemble_sizes = [3, 6, 12, 20]

    for pool_id in range(args.num_pools):
        pool_seed = derive_pool_seed(args.global_seed, pool_id)

        # 控制 representative pool
        set_all_seeds(pool_seed)
        selected_idx, selected_emb = select_mmlu_representatives(
            split=args.split,
            sample_n=args.rep_sample_n,
            seed=pool_seed,
            budget=args.rep_budget,
            return_selected_embeddings=True
        )
        selected_idx = list(map(int, selected_idx))

        print("\n" + "=" * 100)
        print(f"Pool {pool_id} | pool_seed = {pool_seed}")
        print(f"Selected {len(selected_idx)} tasks")
        print(f"First 10 selected task indices: {selected_idx[:10]}")
        print("=" * 100)

        for ensemble_size in ensemble_sizes:
            for ensemble_trial in range(args.num_ensemble_trials):
                metric_seed = derive_metric_seed(
                    args.global_seed,
                    pool_id,
                    ensemble_size,
                    ensemble_trial
                )

                print(
                    f"Running: pool_id={pool_id}, ensemble_size={ensemble_size}, "
                    f"ensemble_trial={ensemble_trial}, metric_seed={metric_seed}"
                )

                # 控制 graph 初始化 + ensemble + noise
                set_all_seeds(metric_seed)

                # 每次都新建 graph，避免状态污染
                graph = build_graph(args)

                metrics = await eki_metrics_per_task_one_step(
                    graph=graph,
                    dataset=dataset,
                    task_indices=selected_idx,
                    num_rounds=args.num_rounds,
                    ensemble_size=ensemble_size,
                    prior_std=args.prior_std,
                    obs_noise=args.obs_noise,
                    damping=args.damping,
                    max_concurrency=args.max_concurrency,
                )

                # 本次实验的逐任务结果
                df_this = pd.DataFrame({
                    'task_idx': selected_idx,
                    'kl': metrics['kl'],
                    'pred_var': metrics['pred_var'],
                    'cosine': metrics['cosine'],
                    'var_list': metrics['var_list'],
                })

                df_this['pool_id'] = pool_id
                df_this['pool_seed'] = pool_seed
                df_this['ensemble_size'] = ensemble_size
                df_this['ensemble_trial'] = ensemble_trial
                df_this['metric_seed'] = metric_seed
                df_this['global_seed'] = args.global_seed

                df_this['rank_kl'] = df_this['kl'].rank(ascending=False, method='min').astype(int)
                df_this['rank_pred_var'] = df_this['pred_var'].rank(ascending=False, method='min').astype(int)
                df_this['rank_cosine'] = df_this['cosine'].rank(ascending=False, method='min').astype(int)
                df_this['rank_var_list'] = df_this['var_list'].rank(ascending=False, method='min').astype(int)

                # 立刻保存 per-task 结果
                append_df_to_csv(df_this, per_task_csv)

                # 取 top-k；如果 rep_budget < 10，也不会报错，只会取到现有任务数
                topk_now = min(10, len(df_this))

                top_kl = df_this.sort_values('kl', ascending=False)['task_idx'].head(topk_now).tolist()
                top_pred_var = df_this.sort_values('pred_var', ascending=False)['task_idx'].head(topk_now).tolist()
                top_cosine = df_this.sort_values('cosine', ascending=False)['task_idx'].head(topk_now).tolist()
                top_var_list = df_this.sort_values('var_list', ascending=False)['task_idx'].head(topk_now).tolist()

                summary_row = {
                    'pool_id': pool_id,
                    'pool_seed': pool_seed,
                    'ensemble_size': ensemble_size,
                    'ensemble_trial': ensemble_trial,
                    'metric_seed': metric_seed,
                    'global_seed': args.global_seed,
                    'num_tasks': len(selected_idx),
                    'topk_used': topk_now,
                    'top10_kl': ",".join(map(str, top_kl)),
                    'top10_pred_var': ",".join(map(str, top_pred_var)),
                    'top10_cosine': ",".join(map(str, top_cosine)),
                    'top10_var_list': ",".join(map(str, top_var_list)),
                    'kl_mean': float(df_this['kl'].mean()),
                    'kl_std': float(df_this['kl'].std()),
                    'pred_var_mean': float(df_this['pred_var'].mean()),
                    'pred_var_std': float(df_this['pred_var'].std()),
                    'cosine_mean': float(df_this['cosine'].mean()),
                    'cosine_std': float(df_this['cosine'].std()),
                    'var_list_mean': float(df_this['var_list'].mean()),
                    'var_list_std': float(df_this['var_list'].std()),
                }

                # 立刻保存 summary 结果
                append_dict_to_csv(summary_row, summary_csv)

                print(f"Saved current run to:")
                print(f"  {per_task_csv}")
                print(f"  {summary_csv}")

        print(f"Finished pool {pool_id}")

    # 全部实验结束后再读取并计算 overlap
    per_task_df = pd.read_csv(per_task_csv)
    summary_df = pd.read_csv(summary_csv)

    # 这里仍然沿用你现在的 overlap 函数
    overlap_kl_df, overlap_kl_agg_df = compute_overlap_tables(summary_df, metric_name='kl', topk=10)
    overlap_pred_var_df, overlap_pred_var_agg_df = compute_overlap_tables(summary_df, metric_name='pred_var', topk=10)

    excel_path = output_dir / 'eki_size_sensitivity.xlsx'
    overlap_kl_csv = output_dir / 'eki_size_sensitivity_overlap_kl.csv'
    overlap_kl_agg_csv = output_dir / 'eki_size_sensitivity_overlap_kl_agg.csv'
    overlap_pred_var_csv = output_dir / 'eki_size_sensitivity_overlap_pred_var.csv'
    overlap_pred_var_agg_csv = output_dir / 'eki_size_sensitivity_overlap_pred_var_agg.csv'

    overlap_kl_df.to_csv(overlap_kl_csv, index=False)
    overlap_kl_agg_df.to_csv(overlap_kl_agg_csv, index=False)
    overlap_pred_var_df.to_csv(overlap_pred_var_csv, index=False)
    overlap_pred_var_agg_df.to_csv(overlap_pred_var_agg_csv, index=False)

    with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
        per_task_df.to_excel(writer, sheet_name='per_task', index=False)
        summary_df.to_excel(writer, sheet_name='summary', index=False)
        overlap_kl_df.to_excel(writer, sheet_name='overlap_kl', index=False)
        overlap_kl_agg_df.to_excel(writer, sheet_name='overlap_kl_agg', index=False)
        overlap_pred_var_df.to_excel(writer, sheet_name='overlap_pred_var', index=False)
        overlap_pred_var_agg_df.to_excel(writer, sheet_name='overlap_pred_var_agg', index=False)

    print("\nAll experiments finished. Saved files:")
    print(f"  {excel_path}")
    print(f"  {per_task_csv}")
    print(f"  {summary_csv}")
    print(f"  {overlap_kl_csv}")
    print(f"  {overlap_kl_agg_csv}")
    print(f"  {overlap_pred_var_csv}")
    print(f"  {overlap_pred_var_agg_csv}")


if __name__ == "__main__":
    asyncio.run(run_experiment())