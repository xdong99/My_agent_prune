import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.stdout.reconfigure(encoding='utf-8')

import asyncio
import argparse
import random
from pathlib import Path
from typing import Union, Literal, List

import numpy as np
import pandas as pd
import torch

from AgentPrune.graph.graph import Graph
from dataset.mmlu_dataset import MMLUDataset
from dataset.MMLU.download import download

from experiments.embedding_mmlu import select_mmlu_representatives
from experiments.train_mmlu_eki import eki_metrics_per_task_multi_step


def parse_args():
    parser = argparse.ArgumentParser(description="EKI-step sensitivity test for EKI task ranking on MMLU.")

    parser.add_argument(
        '--mode',
        type=str,
        default='FullConnected',
        choices=[
            'DirectAnswer', 'FullConnected', 'Random', 'Chain', 'Debate', 'Layered', 'Star', 'Mesh',
            'FakeFullConnected', 'FakeRandom', 'FakeChain', 'FakeStar', 'FakeMesh', 'FakeAGRandom', 'FakeAGFull'
        ],
        help="Mode of operation."
    )
    parser.add_argument('--llm_name', type=str, default='gpt-4.1-nano')
    parser.add_argument('--domain', type=str, default='mmlu')
    parser.add_argument('--decision_method', type=str, default='FinalRefer')

    parser.add_argument('--agent_names', nargs='+', type=str, default=['AnalyzeAgent'])
    parser.add_argument('--agent_nums', nargs='+', type=int, default=[5])

    parser.add_argument('--optimized_spatial', action='store_true')
    parser.add_argument('--optimized_temporal', action='store_true')

    parser.add_argument('--split', type=str, default='test')
    parser.add_argument('--rep_sample_n', type=int, default=1000)
    parser.add_argument('--rep_budget', type=int, default=50)

    parser.add_argument('--global_seed', type=int, default=2026)
    parser.add_argument('--num_pools', type=int, default=3)
    parser.add_argument('--num_ensemble_trials', type=int, default=3)

    # Step-sensitivity settings
    parser.add_argument('--ensemble_size', type=int, default=6)
    parser.add_argument('--num_iters', type=int, default=3)

    parser.add_argument('--num_rounds', type=int, default=1)
    parser.add_argument('--prior_std', type=float, default=2.0)
    parser.add_argument('--obs_noise', type=float, default=0.1)
    parser.add_argument('--damping', type=float, default=0.7)
    parser.add_argument('--max_concurrency', type=int, default=8)
    parser.add_argument('--topk', type=int, default=10)

    parser.add_argument('--output_dir', type=str, default='outputs/eki_step_sensitivity')

    args = parser.parse_args()

    if len(args.agent_names) != len(args.agent_nums):
        parser.error("The number of agent names must match the number of agent counts.")

    if args.num_iters < 1:
        parser.error("num_iters must be at least 1.")

    if args.ensemble_size < 2:
        parser.error("ensemble_size must be at least 2 for covariance estimation.")

    return args


def set_all_seeds(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


def derive_pool_seed(global_seed: int, pool_id: int) -> int:
    return global_seed + 1000 * pool_id + 17


def derive_metric_seed(global_seed: int, pool_id: int, ensemble_size: int, ensemble_trial: int) -> int:
    return global_seed + 100000 * pool_id + 1000 * ensemble_size + 37 * ensemble_trial + 29


def get_kwargs(
    mode: Union[
        Literal['DirectAnswer'], Literal['FullConnected'], Literal['Random'], Literal['Chain'],
        Literal['Debate'], Literal['Layered'], Literal['Star'], Literal['Mesh'],
        Literal['FakeFullConnected'], Literal['FakeRandom'], Literal['FakeChain'],
        Literal['FakeStar'], Literal['FakeMesh'], Literal['FakeAGRandom'], Literal['FakeAGFull']
    ],
    N: int
):
    initial_spatial_probability: float = 0.5
    fixed_spatial_masks: List[List[int]] = None
    initial_temporal_probability: float = 0.5
    fixed_temporal_masks: List[List[int]] = None
    node_kwargs = None

    def generate_layered_graph(N, layer_num=2):
        adj_matrix = [[0] * N for _ in range(N)]
        base_size = N // layer_num
        remainder = N % layer_num
        layers = []
        for i in range(layer_num):
            size = base_size + (1 if i < remainder else 0)
            layers.extend([i] * size)
        random.shuffle(layers)
        for i in range(N):
            current_layer = layers[i]
            for j in range(N):
                if layers[j] == current_layer + 1:
                    adj_matrix[i][j] = 1
        return adj_matrix

    def generate_mesh_graph(N):
        adj_matrix = [[0] * N for _ in range(N)]
        for i in range(0, N):
            for j in range(i + 1, N):
                adj_matrix[i][j] = 1
        return adj_matrix

    def generate_star_graph(N):
        adj_matrix = [[0] * N for _ in range(N)]
        for i in range(1, N):
            adj_matrix[0][i] = 1
        return adj_matrix

    if mode == 'DirectAnswer':
        fixed_spatial_masks = [[0]]
        fixed_temporal_masks = [[0]]
        node_kwargs = [{'role': 'Normal'}]
    elif mode in ['FullConnected', 'FakeFullConnected', 'FakeAGFull']:
        fixed_spatial_masks = [[1 if i != j else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode in ['Random', 'FakeRandom', 'FakeAGRandom']:
        fixed_spatial_masks = [[random.randint(0, 1) if i != j else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[random.randint(0, 1) for _ in range(N)] for _ in range(N)]
    elif mode in ['Chain', 'FakeChain']:
        fixed_spatial_masks = [[1 if i == j + 1 else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[1 if i == 0 and j == N - 1 else 0 for i in range(N)] for j in range(N)]
    elif mode == 'Debate':
        fixed_spatial_masks = [[0 for _ in range(N)] for _ in range(N)]
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode == 'Layered':
        fixed_spatial_masks = generate_layered_graph(N)
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode in ['Mesh', 'FakeMesh']:
        fixed_spatial_masks = generate_mesh_graph(N)
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode in ['Star', 'FakeStar']:
        fixed_spatial_masks = generate_star_graph(N)
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]

    if 'Fake' in mode and 'AG' not in mode:
        node_kwargs = [{'role': 'Fake'} if i % 2 == N % 2 else {'role': 'Normal'} for i in range(N)]
    elif 'Fake' in mode and 'AG' in mode:
        node_kwargs = [{'role': 'Fake'} if i % 2 == N % 2 else {'role': None} for i in range(N)]

    return {
        "initial_spatial_probability": initial_spatial_probability,
        "fixed_spatial_masks": fixed_spatial_masks,
        "initial_temporal_probability": initial_temporal_probability,
        "fixed_temporal_masks": fixed_temporal_masks,
        "node_kwargs": node_kwargs,
    }


def build_graph(args):
    agent_names = [name for name, num in zip(args.agent_names, args.agent_nums) for _ in range(num)]
    kwargs = get_kwargs(args.mode, len(agent_names))

    graph = Graph(
        domain=args.domain,
        llm_name=args.llm_name,
        agent_names=agent_names,
        decision_method=args.decision_method,
        optimized_spatial=args.optimized_spatial,
        optimized_temporal=args.optimized_temporal,
        **kwargs
    )
    return graph


def parse_top_list(text: str):
    if pd.isna(text) or text == "":
        return []
    return [int(x) for x in str(text).split(',') if str(x).strip() != ""]


def compute_step_overlap_tables(
    summary_df: pd.DataFrame,
    metric_name: str = 'kl',
    topk: int = 10,
    baseline_step: int = None,
    include_baseline: bool = True,
):
    """
    Compare the top-k tasks at each EKI step against the baseline step.

    By default, the baseline is the largest step index in the summary table.
    This is useful for checking whether early-step rankings already match the
    final multi-step ranking.
    """
    rows = []
    key = f'top{topk}_{metric_name}'

    if key not in summary_df.columns:
        raise KeyError(f"Column {key} is not found in summary_df.")

    grouped = summary_df.groupby(['pool_id', 'ensemble_trial'])
    for (pool_id, ensemble_trial), subdf in grouped:
        subdf = subdf.sort_values('step')
        step_to_top = {int(row['step']): set(parse_top_list(row[key])) for _, row in subdf.iterrows()}
        steps = sorted(step_to_top.keys())

        ref_step = int(baseline_step) if baseline_step is not None else max(steps)
        if ref_step not in step_to_top:
            continue

        ref_top = step_to_top[ref_step]
        for s in steps:
            if (s == ref_step) and (not include_baseline):
                continue

            cur_top = step_to_top[s]
            denom = min(topk, len(cur_top), len(ref_top))
            overlap_count = len(cur_top & ref_top)
            overlap_ratio = overlap_count / denom if denom > 0 else np.nan

            rows.append({
                'pool_id': pool_id,
                'ensemble_trial': ensemble_trial,
                'step_1': s,
                'step_2': ref_step,
                'topk': topk,
                'topk_denominator': denom,
                'metric': metric_name,
                'overlap_count': overlap_count,
                'overlap_ratio': overlap_ratio,
            })

    pairwise_df = pd.DataFrame(rows)

    if pairwise_df.empty:
        agg_df = pd.DataFrame(columns=[
            'step_1', 'step_2', 'metric', 'topk',
            'overlap_count_mean', 'overlap_count_std',
            'overlap_ratio_mean', 'overlap_ratio_std'
        ])
        return pairwise_df, agg_df

    agg_df = (
        pairwise_df
        .groupby(['step_1', 'step_2', 'metric', 'topk'], as_index=False)
        .agg(
            overlap_count_mean=('overlap_count', 'mean'),
            overlap_count_std=('overlap_count', 'std'),
            overlap_ratio_mean=('overlap_ratio', 'mean'),
            overlap_ratio_std=('overlap_ratio', 'std'),
        )
    )

    return pairwise_df, agg_df


def append_df_to_csv(df: pd.DataFrame, csv_path: Path):
    write_header = not csv_path.exists()
    df.to_csv(csv_path, mode='a', header=write_header, index=False)


def append_dict_to_csv(row_dict: dict, csv_path: Path):
    df = pd.DataFrame([row_dict])
    write_header = not csv_path.exists()
    df.to_csv(csv_path, mode='a', header=write_header, index=False)


def metrics_to_long_df(metrics: dict, selected_idx: List[int]) -> pd.DataFrame:
    """
    Convert metrics returned by eki_metrics_per_task_multi_step into a long table.

    Expected metric shape:
      metrics[name][task_position][step_position]
    where step_position is zero-based. The output uses one-based step indices.
    """
    rows = []
    num_tasks = len(selected_idx)

    for task_pos in range(num_tasks):
        task_idx = int(selected_idx[task_pos])
        num_steps = len(metrics['kl'][task_pos])
        for step_pos in range(num_steps):
            rows.append({
                'task_idx': task_idx,
                'task_pos': task_pos,
                'step': step_pos + 1,
                'kl': float(metrics['kl'][task_pos][step_pos]),
                'pred_var': float(metrics['pred_var'][task_pos][step_pos]),
                'cosine': float(metrics['cosine'][task_pos][step_pos]),
                'var_list': float(metrics['var_list'][task_pos][step_pos]),
            })

    return pd.DataFrame(rows)


async def run_experiment():
    args = parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    per_task_csv = output_dir / 'eki_step_sensitivity_per_task.csv'
    summary_csv = output_dir / 'eki_step_sensitivity_summary.csv'

    # Restart from scratch each time.
    if per_task_csv.exists():
        per_task_csv.unlink()
    if summary_csv.exists():
        summary_csv.unlink()

    download()
    dataset = MMLUDataset(args.split)

    for pool_id in range(args.num_pools):
        pool_seed = derive_pool_seed(args.global_seed, pool_id)

        # Control representative pool.
        set_all_seeds(pool_seed)
        selected_idx, selected_emb = select_mmlu_representatives(
            split=args.split,
            sample_n=args.rep_sample_n,
            seed=pool_seed,
            budget=args.rep_budget,
            return_selected_embeddings=True
        )
        selected_idx = list(map(int, selected_idx))

        print("\n" + "=" * 100)
        print(f"Pool {pool_id} | pool_seed = {pool_seed}")
        print(f"Selected {len(selected_idx)} tasks")
        print(f"First 10 selected task indices: {selected_idx[:10]}")
        print("=" * 100)

        for ensemble_trial in range(args.num_ensemble_trials):
            metric_seed = derive_metric_seed(
                args.global_seed,
                pool_id,
                args.ensemble_size,
                ensemble_trial,
            )

            print(
                f"Running: pool_id={pool_id}, ensemble_size={args.ensemble_size}, "
                f"num_iters={args.num_iters}, ensemble_trial={ensemble_trial}, "
                f"metric_seed={metric_seed}"
            )

            # Control graph initialization + initial ensemble + perturbed observations.
            set_all_seeds(metric_seed)

            # Rebuild graph each time to avoid state contamination.
            graph = build_graph(args)

            metrics = await eki_metrics_per_task_multi_step(
                graph=graph,
                dataset=dataset,
                task_indices=selected_idx,
                num_iters=args.num_iters,
                num_rounds=args.num_rounds,
                ensemble_size=args.ensemble_size,
                prior_std=args.prior_std,
                obs_noise=args.obs_noise,
                damping=args.damping,
                max_concurrency=args.max_concurrency,
            )

            # Per-task, per-step long table.
            df_this = metrics_to_long_df(metrics, selected_idx)

            df_this['pool_id'] = pool_id
            df_this['pool_seed'] = pool_seed
            df_this['ensemble_size'] = args.ensemble_size
            df_this['ensemble_trial'] = ensemble_trial
            df_this['metric_seed'] = metric_seed
            df_this['global_seed'] = args.global_seed
            df_this['num_iters'] = args.num_iters

            # Rank tasks within each step.
            for metric_name in ['kl', 'pred_var', 'cosine', 'var_list']:
                df_this[f'rank_{metric_name}'] = (
                    df_this
                    .groupby('step')[metric_name]
                    .rank(ascending=False, method='min')
                    .astype(int)
                )

            # Save immediately after each pool/trial run.
            append_df_to_csv(df_this, per_task_csv)

            topk_now = min(args.topk, len(selected_idx))

            # One summary row per step.
            for step in sorted(df_this['step'].unique()):
                df_step = df_this[df_this['step'] == step].copy()

                top_kl = df_step.sort_values('kl', ascending=False)['task_idx'].head(topk_now).tolist()
                top_pred_var = df_step.sort_values('pred_var', ascending=False)['task_idx'].head(topk_now).tolist()
                top_cosine = df_step.sort_values('cosine', ascending=False)['task_idx'].head(topk_now).tolist()
                top_var_list = df_step.sort_values('var_list', ascending=False)['task_idx'].head(topk_now).tolist()

                summary_row = {
                    'pool_id': pool_id,
                    'pool_seed': pool_seed,
                    'ensemble_size': args.ensemble_size,
                    'ensemble_trial': ensemble_trial,
                    'metric_seed': metric_seed,
                    'global_seed': args.global_seed,
                    'num_tasks': len(selected_idx),
                    'num_iters': args.num_iters,
                    'step': int(step),
                    'topk_used': topk_now,
                    f'top{args.topk}_kl': ",".join(map(str, top_kl)),
                    f'top{args.topk}_pred_var': ",".join(map(str, top_pred_var)),
                    f'top{args.topk}_cosine': ",".join(map(str, top_cosine)),
                    f'top{args.topk}_var_list': ",".join(map(str, top_var_list)),
                    'kl_mean': float(df_step['kl'].mean()),
                    'kl_std': float(df_step['kl'].std()),
                    'pred_var_mean': float(df_step['pred_var'].mean()),
                    'pred_var_std': float(df_step['pred_var'].std()),
                    'cosine_mean': float(df_step['cosine'].mean()),
                    'cosine_std': float(df_step['cosine'].std()),
                    'var_list_mean': float(df_step['var_list'].mean()),
                    'var_list_std': float(df_step['var_list'].std()),
                }

                append_dict_to_csv(summary_row, summary_csv)

            print("Saved current run to:")
            print(f"  {per_task_csv}")
            print(f"  {summary_csv}")

        print(f"Finished pool {pool_id}")

    # Compute overlap after all experiments finish.
    per_task_df = pd.read_csv(per_task_csv)
    summary_df = pd.read_csv(summary_csv)

    baseline_step = args.num_iters

    overlap_kl_df, overlap_kl_agg_df = compute_step_overlap_tables(
        summary_df,
        metric_name='kl',
        topk=args.topk,
        baseline_step=baseline_step,
        include_baseline=True,
    )
    overlap_pred_var_df, overlap_pred_var_agg_df = compute_step_overlap_tables(
        summary_df,
        metric_name='pred_var',
        topk=args.topk,
        baseline_step=baseline_step,
        include_baseline=True,
    )
    overlap_cosine_df, overlap_cosine_agg_df = compute_step_overlap_tables(
        summary_df,
        metric_name='cosine',
        topk=args.topk,
        baseline_step=baseline_step,
        include_baseline=True,
    )
    overlap_var_list_df, overlap_var_list_agg_df = compute_step_overlap_tables(
        summary_df,
        metric_name='var_list',
        topk=args.topk,
        baseline_step=baseline_step,
        include_baseline=True,
    )

    excel_path = output_dir / 'eki_step_sensitivity.xlsx'
    overlap_kl_csv = output_dir / 'eki_step_sensitivity_overlap_kl.csv'
    overlap_kl_agg_csv = output_dir / 'eki_step_sensitivity_overlap_kl_agg.csv'
    overlap_pred_var_csv = output_dir / 'eki_step_sensitivity_overlap_pred_var.csv'
    overlap_pred_var_agg_csv = output_dir / 'eki_step_sensitivity_overlap_pred_var_agg.csv'
    overlap_cosine_csv = output_dir / 'eki_step_sensitivity_overlap_cosine.csv'
    overlap_cosine_agg_csv = output_dir / 'eki_step_sensitivity_overlap_cosine_agg.csv'
    overlap_var_list_csv = output_dir / 'eki_step_sensitivity_overlap_var_list.csv'
    overlap_var_list_agg_csv = output_dir / 'eki_step_sensitivity_overlap_var_list_agg.csv'

    overlap_kl_df.to_csv(overlap_kl_csv, index=False)
    overlap_kl_agg_df.to_csv(overlap_kl_agg_csv, index=False)
    overlap_pred_var_df.to_csv(overlap_pred_var_csv, index=False)
    overlap_pred_var_agg_df.to_csv(overlap_pred_var_agg_csv, index=False)
    overlap_cosine_df.to_csv(overlap_cosine_csv, index=False)
    overlap_cosine_agg_df.to_csv(overlap_cosine_agg_csv, index=False)
    overlap_var_list_df.to_csv(overlap_var_list_csv, index=False)
    overlap_var_list_agg_df.to_csv(overlap_var_list_agg_csv, index=False)

    with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
        per_task_df.to_excel(writer, sheet_name='per_task', index=False)
        summary_df.to_excel(writer, sheet_name='summary', index=False)
        overlap_kl_df.to_excel(writer, sheet_name='overlap_kl', index=False)
        overlap_kl_agg_df.to_excel(writer, sheet_name='overlap_kl_agg', index=False)
        overlap_pred_var_df.to_excel(writer, sheet_name='overlap_pred_var', index=False)
        overlap_pred_var_agg_df.to_excel(writer, sheet_name='overlap_pred_var_agg', index=False)
        overlap_cosine_df.to_excel(writer, sheet_name='overlap_cosine', index=False)
        overlap_cosine_agg_df.to_excel(writer, sheet_name='overlap_cosine_agg', index=False)
        overlap_var_list_df.to_excel(writer, sheet_name='overlap_var_list', index=False)
        overlap_var_list_agg_df.to_excel(writer, sheet_name='overlap_var_list_agg', index=False)

    print("\nAll experiments finished. Saved files:")
    print(f"  {excel_path}")
    print(f"  {per_task_csv}")
    print(f"  {summary_csv}")
    print(f"  {overlap_kl_csv}")
    print(f"  {overlap_kl_agg_csv}")
    print(f"  {overlap_pred_var_csv}")
    print(f"  {overlap_pred_var_agg_csv}")
    print(f"  {overlap_cosine_csv}")
    print(f"  {overlap_cosine_agg_csv}")
    print(f"  {overlap_var_list_csv}")
    print(f"  {overlap_var_list_agg_csv}")


if __name__ == "__main__":
    asyncio.run(run_experiment())
