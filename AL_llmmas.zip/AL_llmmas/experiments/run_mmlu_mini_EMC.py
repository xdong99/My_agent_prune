import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.stdout.reconfigure(encoding='utf-8')

import asyncio
from typing import Union, Literal, List
import argparse
import random

from AgentPrune.graph.graph import Graph
from dataset.mmlu_dataset import MMLUDataset
from dataset.MMLU.download import download
from experiments.evaluate_mmlu import evaluate
from AgentPrune.utils.const import AgentPrune_ROOT
from AgentPrune.utils.globals import PromptTokens, CompletionTokens

import torch
import pandas as pd
import numpy as np

from experiments.train_mmlu import train, train2, train3
from experiments.train_mmlu_eki import eki_metrics_per_task_one_step
from experiments.embedding_mmlu import select_mmlu_representatives
from experiments.metric_cache import MetricCache, eki_metrics_per_task_one_step_cached

# 新增：导入你刚才那个基于多次 rollout 求平均梯度的文件
#from experiments.train_mmlu_reinforce_combination import compute_task_rollouts_and_grads
#from experiments.train_mmlu_reinforce_combination import compute_task_rollouts_and_grads_avg

from sklearn.preprocessing import StandardScaler
from sklearn.cross_decomposition import PLSRegression
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C, WhiteKernel, Matern
import json
from pathlib import Path
import copy

def parse_args():
    parser = argparse.ArgumentParser(description="Process some parameters.")

    parser.add_argument('--mode', type=str, default='FullConnected',
                        choices=['DirectAnswer', 'FullConnected', 'Random', 'Chain', 'Debate', 'Layered','Star', 'Mesh',
                                 'FakeFullConnected','FakeRandom','FakeChain','FakeStar','FakeMesh','FakeAGRandom','FakeAGFull'],
                        help="Mode of operation. Default is 'FullConnected'.")
    parser.add_argument('--lr', type=float, default=0.1,
                        help="learning rate")
    parser.add_argument('--batch_size', type=int, default=4,
                        help="batch size")
    parser.add_argument('--batch_size_train', type=int, default=4,
                        help="batch size")
    parser.add_argument('--batch_size_test', type=int, default=4,
                        help="batch size")
    parser.add_argument('--agent_names', nargs='+', type=str, default=['AnalyzeAgent'],
                        help='Specify agent names as a list of strings')
    parser.add_argument('--agent_nums', nargs='+', type=int, default=[5],
                        help='Specify the number of agents for each name in agent_names')
    parser.add_argument('--num_iterations', type=int, default=10,
                        help="Number of optimization iterations. Default 10.")
    parser.add_argument('--imp_per_iterations', type=int, default=5,
                        help="Prune every few iterations. Default 5.")
    parser.add_argument('--num_rounds',type=int,default=1,
                        help="Number of optimization/inference rounds for one query")
    parser.add_argument('--return_choice_logprob',type=bool,default=True,
                        help="Return logprob for answer or not")

    parser.add_argument('--eki_iterations',type=int,default=4,
                        help="Number of eki iterations for one query")
    parser.add_argument('--ensemble_size',type=int,default=6,
                        help="Number of ensemble members")
    parser.add_argument('--batch_size_eki',type=int,default=2,
                        help="Number of task for eki")

    parser.add_argument('--pruning_rate', type=float, default=0.25,
                        help="The Rate of Pruning. Default 0.05.")

    parser.add_argument('--llm_name', type=str, default="gpt-4.1-nano",
                        help="Model name, None runs gpt-4.1-nano")
    parser.add_argument('--domain', type=str, default="mmlu",
                        help="Domain (the same as dataset name), default 'mmlu'")
    parser.add_argument('--decision_method', type=str, default="FinalRefer",
                        help="the decision method of the final node")
    parser.add_argument('--optimized_spatial',action='store_true')
    parser.add_argument('--optimized_temporal',action='store_true')

    # 新增：梯度选任务相关参数
    parser.add_argument('--selection_method', type=str, default='gradient_topk',
                        choices=['gradient_topk', 'ts'],
                        help="How to choose final 10 tasks from the 50 representative tasks.")
    parser.add_argument('--num_samples_per_task', type=int, default=3,
                        help="How many rollouts to average per task during gradient-based task selection.")
    parser.add_argument('--selection_topk', type=int, default=10,
                        help="How many tasks to choose from the representative pool.")
    parser.add_argument('--selection_score', type=str, default='l2',
                        choices=['l2', 'sum', 'reward_weighted_l2'],
                        help="How to score each task from its gradient.")
    parser.add_argument('--selection_max_concurrency', type=int, default=8,
                        help="Concurrency for gradient-based task selection.")
    parser.add_argument('--representative_pool_size', type=int, default=50,
                        help="Representative task pool size selected from the initial 1000-sample candidate set.")
    parser.add_argument('--representative_sample_n', type=int, default=1000,
                        help="Initial random candidate pool size before representative selection.")

    args = parser.parse_args()
    result_path = AgentPrune_ROOT / "result"
    os.makedirs(result_path, exist_ok=True)
    if len(args.agent_names) != len(args.agent_nums):
        parser.error("The number of agent names must match the number of agent counts.")
        
    return args


def read_tokens():
    p = int(PromptTokens.instance().value)
    c = int(CompletionTokens.instance().value)
    return p, c


async def eval_and_cache_metrics(
    graph,
    dataset_train,
    task_indices,
    ensemble_size=6,
    out_dir="outputs/metric_cache",
    tag="mmlu50_seed0",
):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    metrics = await eki_metrics_per_task_one_step(
        graph, dataset_train, task_indices, ensemble_size=ensemble_size
    )

    per_task = []
    for i, idx in enumerate(task_indices):
        row = {"idx": int(idx)}
        for k, v in metrics.items():
            row[k] = float(v[i]) if np.isscalar(v[i]) or np.ndim(v) == 1 else v[i]
        per_task.append(row)

    df = pd.DataFrame(per_task)

    csv_path = out_dir / f"{tag}.csv"
    npz_path = out_dir / f"{tag}.npz"
    meta_path = out_dir / f"{tag}.meta.json"

    df.to_csv(csv_path, index=False)

    save_dict = {"idx": df["idx"].to_numpy(dtype=np.int64)}
    for k in metrics.keys():
        save_dict[k] = df[k].to_numpy(dtype=np.float64)
    np.savez_compressed(npz_path, **save_dict)

    meta = {
        "tag": tag,
        "n_tasks": len(task_indices),
        "ensemble_size": ensemble_size,
        "metric_keys": list(metrics.keys()),
        "idx_head": task_indices[:10],
    }
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    print("Saved:", csv_path, npz_path, meta_path)
    return df, metrics


def fit_pls_gp(X_all, y_obs, obs_pos, n_components=3, seed=0):
    X_obs = X_all[obs_pos]
    y_obs = np.asarray(y_obs, dtype=np.float64)

    x_scaler = StandardScaler()
    y_scaler = StandardScaler()

    X_obs_s = x_scaler.fit_transform(X_obs)
    y_t = np.arcsinh(y_obs)
    y_s = y_scaler.fit_transform(y_t.reshape(-1, 1)).ravel()

    pls = PLSRegression(n_components=n_components)
    pls.fit(X_obs_s, y_s)

    X_all_s = x_scaler.transform(X_all)
    Z_all = pls.transform(X_all_s)
    z_scaler = StandardScaler()
    Z_all_s = z_scaler.fit_transform(Z_all)
    Z_obs_s = Z_all_s[obs_pos]

    d = Z_obs_s.shape[1]

    kernel = C(1.0, (1e-3, 1e3)) * Matern(
        length_scale=np.ones(d),
        length_scale_bounds=(1e-2, 1e2),
        nu=2.5
    ) + WhiteKernel(
        noise_level=1e-3,
        noise_level_bounds=(1e-6, 1e-1)
    )

    gp = GaussianProcessRegressor(
        kernel=kernel,
        alpha=1e-4,
        normalize_y=True,
        n_restarts_optimizer=3,
        random_state=seed,
    )

    gp.fit(Z_obs_s, y_s)

    mu, std = gp.predict(Z_all_s, return_std=True)
    return Z_all_s, gp, mu, std


def ts_select_batch(gp, Z_all, candidates_pos, batch_size=5, seed=0):
    samples = gp.sample_y(Z_all, n_samples=1, random_state=seed).ravel()
    cand_scores = samples[candidates_pos]
    order = np.argsort(cand_scores)[::-1]
    pick = candidates_pos[order[:batch_size]]
    return pick, samples


def rank_remaining(mu, candidates_pos):
    order = np.argsort(mu[candidates_pos])[::-1]
    return candidates_pos[order]


def interleave_ends(lst):
    res = []
    i, j = 0, len(lst) - 1
    while i <= j:
        if i == j:
            res.append(lst[i])
        else:
            res.append(lst[i])
            res.append(lst[j])
        i += 1
        j -= 1
    return res


def batch_ts_topk(gp, Z_all, k=10, n_draws=200, seed=0):
    rng = np.random.default_rng(seed)
    counts = np.zeros(Z_all.shape[0], dtype=int)
    for d in range(n_draws):
        s = gp.sample_y(Z_all, n_samples=1, random_state=int(rng.integers(1e9))).ravel()
        topk = np.argsort(s)[::-1][:k]
        counts[topk] += 1
    order = np.argsort(counts)[::-1]
    return order[:k], counts / n_draws


def count_common(a, b):
    return len(set(a) & set(b))


# ===================== 新增：基于梯度的单任务打分 =====================

def score_task_from_logit_change(task_record, score_type="l2"):
    delta = task_record["delta_flat"]

    if score_type == "l2":
        return float(delta.norm(p=2).item())
    elif score_type == "sum":
        return float(delta.sum().item())
    else:
        raise ValueError(f"Unknown score_type: {score_type}")

async def evaluate_one_task_by_logit_change(
    graph,
    dataset,
    task_idx,
    *,
    num_rounds=1,
    train_steps=3,
    lr=0.1,
    batch_size=1,
    imp_per_iters=1000000,
    pruning_rate=0.0,
):
    """
    对单个 task:
      1. deepcopy 一份 graph
      2. 记录训练前 logits
      3. 用 train2 在这个单任务上训练 train_steps 步
      4. 比较训练前后 logits 的变化量
    """
    graph_copy = copy.deepcopy(graph)

    with torch.no_grad():
        spatial_before = graph_copy.spatial_logits.detach().clone()
        temporal_before = graph_copy.temporal_logits.detach().clone()

    await train2(
        graph=graph_copy,
        dataset=dataset,
        task_indices=[int(task_idx)],
        num_iters=train_steps,
        num_rounds=num_rounds,
        lr=lr,
        batch_size=batch_size,
        imp_per_iters=imp_per_iters,
        pruning_rate=pruning_rate,
    )

    with torch.no_grad():
        spatial_after = graph_copy.spatial_logits.detach().clone()
        temporal_after = graph_copy.temporal_logits.detach().clone()

        delta_spatial = spatial_after - spatial_before
        delta_temporal = temporal_after - temporal_before
        delta_flat = torch.cat(
            [delta_spatial.reshape(-1), delta_temporal.reshape(-1)],
            dim=0
        )

    return {
        "idx": int(task_idx),
        "delta_spatial": delta_spatial,
        "delta_temporal": delta_temporal,
        "delta_flat": delta_flat,
    }

async def select_topk_by_logit_change(
    graph,
    dataset,
    task_indices,
    *,
    num_rounds=1,
    max_concurrency=8,
    topk=10,
    score_type="l2",
    train_steps=3,
    lr=0.1,
    batch_size=1,
    imp_per_iters=1000000,
    pruning_rate=0.0,
):
    """
    对每个候选 task：
      - 从同一个初始 graph 出发
      - 用该 task 训练若干步
      - 用训练前后 logits 的差的大小作为分数
    """
    sem = asyncio.Semaphore(max_concurrency)

    async def _run_one(idx):
        async with sem:
            out = await evaluate_one_task_by_logit_change(
                graph=graph,
                dataset=dataset,
                task_idx=int(idx),
                num_rounds=num_rounds,
                train_steps=train_steps,
                lr=lr,
                batch_size=batch_size,
                imp_per_iters=imp_per_iters,
                pruning_rate=pruning_rate,
            )
            return out

    per_task = await asyncio.gather(
        *[asyncio.create_task(_run_one(idx)) for idx in task_indices]
    )

    scored = []
    for d in per_task:
        score = score_task_from_logit_change(d, score_type=score_type)
        scored.append({
            "idx": int(d["idx"]),
            "score": float(score),
        })

    scored_sorted = sorted(scored, key=lambda x: x["score"], reverse=True)
    topk_idx = [x["idx"] for x in scored_sorted[:topk]]

    print("\n===== Logit-change-based selection ranking =====")
    for i, row in enumerate(scored_sorted[:min(len(scored_sorted), 20)]):
        print(f"[{i:02d}] idx={row['idx']} score={row['score']:.6f}")

    return {
        "topk_idx": topk_idx,
        "scored_sorted": scored_sorted,
        "per_task": per_task,
    }


# ======================== main ==========================

async def main():
    args = parse_args()
    
    mode = args.mode
    decision_method = args.decision_method
    agent_names = [name for name, num in zip(args.agent_names, args.agent_nums) for _ in range(num)]
    kwargs = get_kwargs(mode, len(agent_names))
    limit_questions = 153
    
    graph = Graph(
        domain=args.domain,
        llm_name=args.llm_name,
        agent_names=agent_names,
        decision_method=decision_method,
        optimized_spatial=args.optimized_spatial,
        optimized_temporal=args.optimized_temporal,
        **kwargs
    )

    print("agent+role:", [(node.agent_name, node.role, node.id) for node in graph.nodes.values()])

    download()
    dataset_train = MMLUDataset('test')
    dataset_val = MMLUDataset('val')

    # ===== representative selection =====
    pn1, cn1 = read_tokens()

    seed_number = 1098#24#0#123#1024#1345#42#

    selected_idx, selected_emb = select_mmlu_representatives(
        split="test",
        sample_n=args.representative_sample_n,
        seed=seed_number,
        budget=args.representative_pool_size,
        return_selected_embeddings=True
    )

    idx_all = np.array(selected_idx)
    X_all = np.asarray(selected_emb)

    print("\n===== Representative pool selected =====")
    print("Representative pool size:", len(idx_all))
    print("Representative indices head:", idx_all[:10].tolist())

    
    # ===== choose final 10 tasks =====
    if args.selection_method == "gradient_topk":
        print("\n===== Using logit-change-based top-k selection =====")
        select_out = await select_topk_by_logit_change(
            graph=graph,
            dataset=dataset_train,
            task_indices=idx_all.tolist(),
            num_rounds=args.num_rounds,
            max_concurrency=args.selection_max_concurrency,
            topk=args.selection_topk,
            score_type=args.selection_score,
            train_steps=3,
            lr=args.lr,
            batch_size=1,
            imp_per_iters=1000000,
            pruning_rate=0.0,
        )
        top10_idx = select_out["topk_idx"]

    elif args.selection_method == "ts":
        print("\n===== Using original TS selection =====")

        rng_1 = np.random.default_rng(seed_number)
        init_pos = rng_1.choice(len(idx_all), size=10, replace=False)
        obs_pos = list(init_pos)

        init_task_indices = idx_all[init_pos].tolist()
        m0 = await eki_metrics_per_task_one_step(graph, dataset_train, init_task_indices, ensemble_size=6)
        y_obs = list(np.asarray(m0["kl"], dtype=np.float64))

        observed_mask = np.zeros(len(idx_all), dtype=bool)
        observed_mask[obs_pos] = True

        num_rounds_ts = 3
        batch_size_ts = 5

        for t in range(num_rounds_ts):
            Z_all, gp, mu, std = fit_pls_gp(X_all, y_obs, np.array(obs_pos), n_components=3, seed=t * 10 + 1)

            candidates_pos = np.where(~observed_mask)[0]
            if len(candidates_pos) == 0:
                break

            pick_pos, samples = ts_select_batch(
                gp, Z_all, candidates_pos,
                batch_size=min(batch_size_ts, len(candidates_pos)),
                seed=t * 20 + 3
            )
            pick_idx = idx_all[pick_pos].tolist()

            m_new = await eki_metrics_per_task_one_step(graph, dataset_train, pick_idx, ensemble_size=6)
            y_new = np.asarray(m_new["kl"], dtype=np.float64)

            for p, yv in zip(pick_pos.tolist(), y_new.tolist()):
                obs_pos.append(int(p))
                y_obs.append(float(yv))
                observed_mask[p] = True

            remaining_pos = np.where(~observed_mask)[0]
            if len(remaining_pos) > 0:
                ranked_pos = rank_remaining(mu, remaining_pos)
                ranked_idx = idx_all[ranked_pos].tolist()
                print(f"[Round {t}] picked idx:", pick_idx)
                print(f"[Round {t}] top-10 remaining by mean:", ranked_idx[:10])
            else:
                print(f"[Round {t}] picked idx:", pick_idx)
                print(f"[Round {t}] no remaining tasks.")

        Z_all, gp, mu, std = fit_pls_gp(X_all, y_obs, np.array(obs_pos), n_components=3, seed=t * 30 + 5)
        top10_pos, prob = batch_ts_topk(gp, Z_all, k=args.selection_topk, n_draws=200, seed=t * 50 + 15)
        top10_idx = idx_all[top10_pos].tolist()

    else:
        raise ValueError(f"Unknown selection_method: {args.selection_method}")
    


    # ===== train =====
    print("Before train: graph")
    print(graph.spatial_logits.detach())
    print(graph.temporal_logits.detach())

    top10_idx_true = [13551, 7816, 4683, 13035, 2763, 2459, 11965, 366, 13348, 9937]
    top10_idx_resort = interleave_ends(top10_idx)

    #top10_idx_resort = [5793, 7667, 10114, 10701, 12710, 5863, 12782, 6311, 12634, 8138]


    #print("=== Chosen task resort ===", top10_idx_resort)
    #print("=== Chosen task unresorted ===", top10_idx)
    #print("=== True task ===", top10_idx_true)
    #print("same task number", count_common(top10_idx, top10_idx_true))

    p0, c0 = read_tokens()

    if args.optimized_spatial or args.optimized_temporal:
        await train2(
            graph=graph,
            dataset=dataset_train,
            task_indices=top10_idx_resort,
            num_iters=args.num_iterations,
            num_rounds=args.num_rounds,
            lr=args.lr,
            batch_size=args.batch_size_train,
            imp_per_iters=args.imp_per_iterations,
            pruning_rate=args.pruning_rate
        )
    
    print("After train: graph")
    print(graph.spatial_logits.detach())
    print(graph.temporal_logits.detach())

    p1, c1 = read_tokens()
    train_prompt = p1 - p0
    train_completion = c1 - c0

    p2, c2 = read_tokens()

    score = await evaluate(
        graph=graph,
        dataset=dataset_val,
        num_rounds=args.num_rounds,
        limit_questions=limit_questions,
        eval_batch_size=args.batch_size_test
    )
    
    p3, c3 = read_tokens()
    eval_prompt = p3 - p2
    eval_completion = c3 - c2
    
    print("=== Chosen task resorted ===", top10_idx_resort)
    task_prompt = p0 - pn1
    task_completion = c0 - cn1
    print("=== Task evaluation tokens ===", task_prompt, task_completion, task_prompt + task_completion)
    print("=== Train tokens ===", train_prompt, train_completion, train_prompt + train_completion)
    print("=== Eval tokens  ===", eval_prompt, eval_completion, eval_prompt + eval_completion)
    print("=== Total tokens ===", p3, c3, p3 + c3)
    print(f"Score: {score}")


def get_kwargs(mode: Union[
                    Literal['DirectAnswer'],
                    Literal['FullConnected'],
                    Literal['Random'],
                    Literal['Chain'],
                    Literal['Debate'],
                    Literal['Layered'],
                    Literal['Star'],
                    Literal['Mesh'],
                    Literal['FakeFullConnected'],
                    Literal['FakeRandom'],
                    Literal['FakeChain'],
                    Literal['FakeStar'],
                    Literal['FakeMesh'],
                    Literal['FakeAGRandom'],
                    Literal['FakeAGFull']],
               N: int):
    initial_spatial_probability: float = 0.5
    fixed_spatial_masks: List[List[int]] = None
    initial_temporal_probability: float = 0.5
    fixed_temporal_masks: List[List[int]] = None
    node_kwargs = None
    
    def generate_layered_graph(N, layer_num=2):
        adj_matrix = [[0] * N for _ in range(N)]
        base_size = N // layer_num
        remainder = N % layer_num
        layers = []
        for i in range(layer_num):
            size = base_size + (1 if i < remainder else 0)
            layers.extend([i] * size)
        random.shuffle(layers)
        for i in range(N):
            current_layer = layers[i]
            for j in range(N):
                if layers[j] == current_layer + 1:
                    adj_matrix[i][j] = 1
        return adj_matrix
    
    def generate_mesh_graph(N):
        adj_matrix = [[0] * N for _ in range(N)]
        for i in range(0, N):
            for j in range(i + 1, N):
                adj_matrix[i][j] = 1
        return adj_matrix
    
    def generate_star_graph(N):
        adj_matrix = [[0] * N for _ in range(N)]
        for i in range(1, N):
            adj_matrix[0][i] = 1
        return adj_matrix
    
    if mode == 'DirectAnswer':
        fixed_spatial_masks = [[0]]
        fixed_temporal_masks = [[0]]
        node_kwargs = [{'role': 'Normal'}]
    elif mode == 'FullConnected' or mode == 'FakeFullConnected' or mode == 'FakeAGFull':
        fixed_spatial_masks = [[1 if i != j else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode == 'Random' or mode == 'FakeRandom' or mode == 'FakeAGRandom':
        fixed_spatial_masks = [[random.randint(0, 1) if i != j else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[random.randint(0, 1) for _ in range(N)] for _ in range(N)]
    elif mode == 'Chain' or mode == 'FakeChain':
        fixed_spatial_masks = [[1 if i == j + 1 else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[1 if i == 0 and j == N - 1 else 0 for i in range(N)] for j in range(N)]
    elif mode == 'Debate':
        fixed_spatial_masks = [[0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[1 for i in range(N)] for j in range(N)]
    elif mode == 'Layered':
        fixed_spatial_masks = generate_layered_graph(N)
        fixed_temporal_masks = [[1 for i in range(N)] for j in range(N)]
    elif mode == 'Mesh' or mode == 'FakeMesh':
        fixed_spatial_masks = generate_mesh_graph(N)
        fixed_temporal_masks = [[1 for i in range(N)] for j in range(N)]
    elif mode == 'Star' or mode == 'FakeStar':
        fixed_spatial_masks = generate_star_graph(N)
        fixed_temporal_masks = [[1 for i in range(N)] for j in range(N)]
    
    if 'Fake' in mode and 'AG' not in mode:
        node_kwargs = [{'role': 'Fake'} if i % 2 == N % 2 else {'role': 'Normal'} for i in range(N)]
    elif 'Fake' in mode and 'AG' in mode:
        node_kwargs = [{'role': 'Fake'} if i % 2 == N % 2 else {'role': None} for i in range(N)]
        
    return {
        "initial_spatial_probability": initial_spatial_probability,
        "fixed_spatial_masks": fixed_spatial_masks,
        "initial_temporal_probability": initial_temporal_probability,
        "fixed_temporal_masks": fixed_temporal_masks,
        "node_kwargs": node_kwargs
    }


def summarize_graph(graph, tag: str = ""):
    with torch.no_grad():
        print(f"\n===== {tag} =====")
        if hasattr(graph, "spatial_logits") and graph.spatial_logits is not None:
            s = graph.spatial_logits.detach().float().cpu()
            print(f"spatial_logits: shape={tuple(s.shape)} "
                  f"min={s.min().item():.6e} max={s.max().item():.6e} mean={s.mean().item():.6e} "
                  f"sigmoid_mean={torch.sigmoid(s).mean().item():.6e} "
                  f"requires_grad={graph.spatial_logits.requires_grad}")
        else:
            print("spatial_logits: <missing>")

        if hasattr(graph, "temporal_logits") and graph.temporal_logits is not None:
            t = graph.temporal_logits.detach().float().cpu()
            print(f"temporal_logits: shape={tuple(t.shape)} "
                  f"min={t.min().item():.6e} max={t.max().item():.6e} mean={t.mean().item():.6e} "
                  f"sigmoid_mean={torch.sigmoid(t).mean().item():.6e} "
                  f"requires_grad={graph.temporal_logits.requires_grad}")
        else:
            print("temporal_logits: <missing>")

        if hasattr(graph, "spatial_mask"):
            sm = getattr(graph, "spatial_mask")
            if sm is not None:
                sm = sm.detach().cpu()
                print(f"spatial_mask: active={int(sm.sum().item())}/{sm.numel()}")

        if hasattr(graph, "temporal_mask"):
            tm = getattr(graph, "temporal_mask")
            if tm is not None:
                tm = tm.detach().cpu()
                print(f"temporal_mask: active={int(tm.sum().item())}/{tm.numel()}")


if __name__ == "__main__":
    asyncio.run(main())