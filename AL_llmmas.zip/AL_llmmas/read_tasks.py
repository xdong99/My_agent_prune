import sys
import os
from pathlib import Path
import numpy as np
import pandas as pd

sys.path.append(os.path.abspath("."))

from dataset.mmlu_dataset import MMLUDataset
from dataset.MMLU.download import download

# =========================
# Settings
# =========================
per_task_path = Path("outputs/eki_step_sensitivity/eki_step_sensitivity_per_task.csv")

pool_id = 0
ensemble_trial = 2
rank_positions = [0, 5, 10, 15, 20, 25, 30, 45]  # 0-based rank
rank_metric = "kl"
rank_step = None  # None means last step
split = "test"


def record_to_dict(record):
    if hasattr(record, "to_dict"):
        return record.to_dict()
    if isinstance(record, dict):
        return dict(record)
    return {"raw_record": str(record)}


# =========================
# Load saved EKI metrics
# =========================
df = pd.read_csv(per_task_path)

sub = df[
    (df["pool_id"] == pool_id) &
    (df["ensemble_trial"] == ensemble_trial)
].copy()

if rank_step is None:
    rank_step = int(sub["step"].max())

df_rank = sub[sub["step"] == rank_step].copy()
df_rank = df_rank.sort_values(rank_metric, ascending=False).reset_index(drop=True)

df_rank["rank_position_0based"] = np.arange(len(df_rank))
df_rank["rank_position_1based"] = df_rank["rank_position_0based"] + 1

picked = df_rank[df_rank["rank_position_0based"].isin(rank_positions)].copy()

# =========================
# Load dataset
# =========================
download()
dataset = MMLUDataset(split)

# =========================
# Print selected tasks
# =========================
for _, row in picked.iterrows():
    task_idx = int(row["task_idx"])
    record = record_to_dict(dataset[task_idx])

    print("=" * 100)
    print(f"KL rank: {int(row['rank_position_1based'])}")
    print(f"task_idx: {task_idx}")
    print(f"KL: {row['kl']:.6g}")
    print(f"pred_var: {row['pred_var']:.6g}")
    print(f"cosine: {row['cosine']:.6g}")
    print(f"var_list: {row['var_list']:.6g}")
    print(f"rank_pred_var: {int(row['rank_pred_var'])}")
    print(f"rank_cosine: {int(row['rank_cosine'])}")
    print(f"rank_var_list: {int(row['rank_var_list'])}")

    print("\nTask content:")

    # 优先按常见字段打印
    for key in ["subject", "question", "A", "B", "C", "D", "answer", "target", "correct_answer"]:
        if key in record:
            print(f"{key}: {record[key]}")

    # 如果字段名不匹配，就打印整个 record
    common_keys = {"subject", "question", "A", "B", "C", "D", "answer", "target", "correct_answer"}
    if not any(k in record for k in common_keys):
        print(record)

print("=" * 100)