import asyncio
import os
from AgentPrune.llm.gpt_chat import GPTChat


def format_mcq(question: str, A: str, B: str, C: str, D: str) -> str:
    return (
        f"{question}\n\n"
        f"A) {A}\n"
        f"B) {B}\n"
        f"C) {C}\n"
        f"D) {D}\n"
        f"\nAnswer:"
    )


async def main():
    model_name = os.getenv("MODEL_NAME", "gpt-4o-mini")
    llm = GPTChat(model_name=model_name)

    # One MMLU-style question (example)
    question = "In Python 3, which of the following function convert a string to an int in python?"
    A = "int(x[, base])"
    B = "long(x[, base])"
    C = "float(x)"
    D = "str(x)"

    correct_answer = "A"  # int(...) converts to int in Python 3

    user_prompt = format_mcq(question, A, B, C, D)

    messages = [
        {
            "role": "system",
            "content": (
                "I will ask you a question.\n"
                "I will also give you 4 answers enumerated as A, B, C and D.\n"
                "Only one answer out of the offered 4 is correct.\n"
                "You must choose the correct answer to the question.\n"
                "Your response must be one of the 4 letters: A, B, C or D.\n"
                "Your reply must only contain one letter and cannot have any other characters.\n"
            ),
        },
        {"role": "user", "content": user_prompt},
    ]

    out = await llm.agen(messages, return_choice_logprob=True)

    print("\n=== Model raw output dict ===")
    print(out)

    print("\n=== Extracted ===")
    print("text:", repr(out.get("text")))
    print("choice:", out.get("choice"))
    print("choice_logprob:", out.get("choice_logprob"))

    abcd_logprobs = out.get("abcd_logprobs", {})
    abcd_probs = out.get("abcd_probs", {})

    print("\n=== ABCD logprobs (missing -> -inf) ===")
    for k in ["A", "B", "C", "D"]:
        print(k, abcd_logprobs.get(k))

    print("\n=== ABCD probs (softmax in ABCD subspace) ===")
    for k in ["A", "B", "C", "D"]:
        print(k, abcd_probs.get(k))

    print("\n=== p(correct) ===")
    print("correct =", correct_answer, "p_correct =", abcd_probs.get(correct_answer))


if __name__ == "__main__":
    asyncio.run(main())
