# tests/check_subject_contiguity.py
import argparse
from collections import defaultdict, Counter

def iter_subjects(ds, max_questions: int):
    """
    Yield (idx, subject) in the SAME order as: for idx, record in enumerate(ds)
    Prefer ds._total_df_with_subject if available (as in your allocation script).
    """
    n = len(ds)
    if max_questions is None or max_questions < 0:
        max_questions = n
    max_questions = min(max_questions, n)

    # Fast path: you already maintain a dataframe with subject
    if hasattr(ds, "_total_df_with_subject"):
        df = ds._total_df_with_subject
        for i in range(max_questions):
            yield i, df.iloc[i]["subject"]
        return

    # Fallback: try to extract subject from record or a helper function
    for i, record in enumerate(ds):
        if i >= max_questions:
            break

        subj = None
        # common patterns
        if isinstance(record, dict):
            subj = record.get("subject", None)

        if subj is None and hasattr(ds, "record_to_subject"):
            try:
                subj = ds.record_to_subject(record)
            except Exception:
                subj = None

        if subj is None:
            raise RuntimeError(
                "Cannot find subject. Please ensure dataset has _total_df_with_subject "
                "or record contains 'subject' or dataset provides record_to_subject(record)."
            )

        yield i, subj


def contiguous_intervals(indices):
    """Given sorted indices, return list of [start,end] inclusive intervals of consecutive integers."""
    if not indices:
        return []
    intervals = []
    s = e = indices[0]
    for x in indices[1:]:
        if x == e + 1:
            e = x
        else:
            intervals.append((s, e))
            s = e = x
    intervals.append((s, e))
    return intervals


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--split", type=str, default="val", choices=["dev", "val", "test"])
    parser.add_argument("--max_questions", type=int, default=-1,
                        help="How many questions from the start to test. -1 means all.")
    parser.add_argument("--print_first", type=int, default=50,
                        help="Print first K subjects to eyeball transitions.")
    parser.add_argument("--show_top_bad", type=int, default=20,
                        help="Show top K subjects that are NOT contiguous.")
    args = parser.parse_args()

    # Adjust import to match your repo
    from dataset.mmlu_dataset import MMLUDataset
    ds = MMLUDataset(split=args.split)

    subjects = []
    idx2subj = []
    for i, subj in iter_subjects(ds, args.max_questions):
        subjects.append(subj)
        idx2subj.append((i, subj))

    N = len(subjects)
    if N == 0:
        print("No data.")
        return

    # Basic run-length stats (how many consecutive same-subject chunks)
    runs = []
    transitions = 0
    cur_subj = subjects[0]
    run_len = 1
    for s in subjects[1:]:
        if s == cur_subj:
            run_len += 1
        else:
            runs.append((cur_subj, run_len))
            transitions += 1
            cur_subj = s
            run_len = 1
    runs.append((cur_subj, run_len))

    run_lens = [l for _, l in runs]
    max_run = max(run_lens)
    max_run_subject = runs[run_lens.index(max_run)][0]
    avg_run = sum(run_lens) / len(run_lens)

    # For each subject, check whether it appears in a single contiguous block
    positions = defaultdict(list)
    for i, s in enumerate(subjects):
        positions[s].append(i)

    non_contig = []
    for s, idxs in positions.items():
        # contiguous iff range length equals count
        if (idxs[-1] - idxs[0] + 1) != len(idxs):
            intervals = contiguous_intervals(idxs)
            non_contig.append((s, len(idxs), len(intervals), intervals[:5]))  # keep first 5 intervals preview

    non_contig.sort(key=lambda x: (x[2], x[1]), reverse=True)  # more blocks first, then more occurrences

    # Report
    print(f"\nSplit: {args.split}")
    print(f"Checked questions: {N} (from the start)")
    print(f"Unique subjects: {len(positions)}")
    print(f"Subject transitions: {transitions}")
    print(f"Run count (subject chunks): {len(runs)}")
    print(f"Avg run length: {avg_run:.2f}")
    print(f"Max run length: {max_run} (subject='{max_run_subject}')")

    print("\nFirst subjects (to eyeball):")
    K = min(args.print_first, N)
    for i in range(K):
        print(f"{i:5d}  {subjects[i]}")

    print("\nContiguity check (does each subject appear in exactly ONE block?):")
    if not non_contig:
        print("All subjects are contiguous blocks (each subject appears in a single consecutive segment).")
    else:
        print(f"Found {len(non_contig)} NON-contiguous subjects (appear in multiple blocks). Showing top {args.show_top_bad}:")
        print("subject | count | blocks | first_intervals_preview")
        for s, cnt, blocks, preview in non_contig[:args.show_top_bad]:
            print(f"{s} | {cnt} | {blocks} | {preview}")

    # Optional: distribution of run lengths
    dist = Counter(run_lens)
    print("\nRun-length distribution (length -> how many chunks):")
    for l in sorted(dist):
        print(f"{l:4d} -> {dist[l]}")

if __name__ == "__main__":
    main()
