import asyncio
import os

# 如果你的文件在 AgentPrune/llm/gpt_chat.py，一般这样导入
from AgentPrune.llm.gpt_chat import GPTChat

async def main():
    # 用你项目里实际在用的模型名；如果你有环境变量就用环境变量
    model_name = os.getenv("MODEL_NAME", "gpt-4o-mini")
    llm = GPTChat(model_name=model_name)

    messages = [
        {"role": "system", "content": "You must reply with exactly one letter: A, B, C, or D."},
        {"role": "user", "content": "1+1 = ?\nA) 1\nB) 2\nC) 3\nD) 4\nReply with one letter only."},
    ]

    print("\n=== Case 1: default (should return str) ===")
    out1 = await llm.agen(messages)
    print("type:", type(out1))
    print("value:", repr(out1))

    print("\n=== Case 2: return_choice_logprob=True (should return dict/tuple) ===")
    out2 = await llm.agen(messages, return_choice_logprob=True)
    print("type:", type(out2))
    print("value:", out2)

    # 如果你返回的是 dict，做一个更明确的检查（按需改字段名）
    if isinstance(out2, dict):
        print("text:", repr(out2.get("text")))
        print("choice:", out2.get("choice"))
        print("choice_logprob:", out2.get("choice_logprob"))

if __name__ == "__main__":
    asyncio.run(main())
