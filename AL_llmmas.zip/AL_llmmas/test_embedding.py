from experiments.embedding_mmlu import select_mmlu_representatives
selected_idx, selected_emb = select_mmlu_representatives(split="test", sample_n=1000, seed=0, budget=20, return_selected_embeddings=True)
print(selected_idx)
print(selected_emb[0][:10])
print(type(selected_idx))
print(type(selected_emb))
print(type(selected_emb[0]))
print(selected_emb.dtype)