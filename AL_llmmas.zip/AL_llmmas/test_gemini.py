import os
import asyncio
from dotenv import load_dotenv
from google import genai

load_dotenv() 


async def main():
    key = os.getenv("GEMINI_API_KEY")
    assert key, "Missing GEMINI_API_KEY"
    client = genai.Client(api_key=key)
    async with client.aio as aclient:
        resp = await aclient.models.generate_content(
            model="gemini-2.5-flash-preview-09-2025",
            contents="Explain how AI works in a few words.",
        )
    print(resp.text)

if __name__ == "__main__":
    asyncio.run(main())
