import asyncio
#import AgentPrune.llm.gemini_chat
from AgentPrune.llm.llm_registry import LLMRegistry

async def main():
    llm = LLMRegistry.get("gemini-2.5-flash-preview-09-2025")
    out = await llm.agen([{"role": "user", "content": "Say hi."}])
    print(out)

asyncio.run(main())
