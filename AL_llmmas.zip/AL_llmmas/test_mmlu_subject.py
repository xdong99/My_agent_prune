import numpy as np

from dataset.mmlu_dataset import MMLUDataset  # 按你的实际 import 路径改

def main():
    ds = MMLUDataset(split="test")  # 或 "test"/"dev"，按你项目支持的 split 改

    print("len(ds) =", len(ds))

    # 1) 抽 3 条，检查 getitem 旧接口仍可用
    for i in [0, 1, 2]:
        r = ds[i]
        print(f"\n--- record {i} ---")
        # 旧 record 应该是 dict / Series（看你原实现）
        if hasattr(r, "keys"):
            print("keys:", list(r.keys()))
        else:
            print("type(record):", type(r))

        # 2) 新 subject 能取到
        subj = ds.get_subject(i) if hasattr(ds, "get_subject") else ds._total_df_with_subject.iloc[i]["subject"]
        print("subject:", subj)

        # 3) 输入拼接（确认包含选项）
        inp = ds.record_to_input(r)
        print("input preview:", str(inp)[:200])

    # 4) 顺序一致性硬检查（随机抽 20 个 index）
    rng = np.random.default_rng(0)
    idxs = rng.choice(len(ds), size=20, replace=False)

    cols = ["question", "A", "B", "C", "D", "correct_answer"]
    for idx in idxs:
        r_old = ds._total_df.iloc[idx]
        r_new = ds._total_df_with_subject.iloc[idx]
        for c in cols:
            if r_old[c] != r_new[c]:
                raise RuntimeError(f"Mismatch at idx={idx}, col={c}")

    print("\n✅ Order check passed: _total_df and _total_df_with_subject align perfectly.")

    # 5) 统计随机抽 1000 题的 subject 分布
    sample_n = min(1000, len(ds))
    idxs = rng.choice(len(ds), size=sample_n, replace=False)
    subjects = ds._total_df_with_subject.iloc[idxs]["subject"].tolist()
    from collections import Counter
    cnt = Counter(subjects)
    print(f"\nTop 10 subjects in a random sample of {sample_n}:")
    for k, v in cnt.most_common(10):
        print(k, v)

if __name__ == "__main__":
    main()
