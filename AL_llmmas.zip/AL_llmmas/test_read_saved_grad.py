import torch, json

grads = torch.load("outputs/combo_dump/combo_grads.pt")  # (num_combos, D)
combos = torch.load("outputs/combo_dump/combo_index.pt") # list[list[int]]

# 如果要读 meta：
with open("outputs/combo_dump/combo_meta.jsonl", "r") as f:
    meta = [json.loads(line) for line in f]

breakpoint()