import os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
sys.stdout.reconfigure(encoding="utf-8")

import argparse
import asyncio
import random
import torch

from AgentPrune.graph.graph import Graph
from dataset.mmlu_dataset import MMLUDataset
from dataset.MMLU.download import download

# 你保存的两个函数在这里
from experiments.train_mmlu_reinforce_combination import (
    rollout_one_task,
    reinforce_one_step_from_rollouts,
)


def get_kwargs(mode: str, N: int):
    """
    直接从 run_mmlu.py 参考过来的最小版本，只保留常用的几种 mode。
    FullConnected/Random/Chain/Debate/Layered/Star/Mesh 都能用。
    参考：run_mmlu.py 的 get_kwargs :contentReference[oaicite:2]{index=2}
    """
    initial_spatial_probability = 0.5
    initial_temporal_probability = 0.5
    fixed_spatial_masks = None
    fixed_temporal_masks = None
    node_kwargs = None

    def generate_layered_graph(N, layer_num=2):
        adj_matrix = [[0] * N for _ in range(N)]
        base_size = N // layer_num
        remainder = N % layer_num
        layers = []
        for i in range(layer_num):
            size = base_size + (1 if i < remainder else 0)
            layers.extend([i] * size)
        random.shuffle(layers)
        for i in range(N):
            current_layer = layers[i]
            for j in range(N):
                if layers[j] == current_layer + 1:
                    adj_matrix[i][j] = 1
        return adj_matrix

    def generate_mesh_graph(N):
        adj_matrix = [[0] * N for _ in range(N)]
        for i in range(N):
            for j in range(i + 1, N):
                adj_matrix[i][j] = 1
        return adj_matrix

    def generate_star_graph(N):
        adj_matrix = [[0] * N for _ in range(N)]
        for i in range(1, N):
            adj_matrix[0][i] = 1
        return adj_matrix

    if mode == "DirectAnswer":
        fixed_spatial_masks = [[0]]
        fixed_temporal_masks = [[0]]
        node_kwargs = [{"role": "Normal"}]
    elif mode == "FullConnected":
        fixed_spatial_masks = [[1 if i != j else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode == "Random":
        fixed_spatial_masks = [[random.randint(0, 1) if i != j else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[random.randint(0, 1) for _ in range(N)] for _ in range(N)]
    elif mode == "Chain":
        fixed_spatial_masks = [[1 if i == j + 1 else 0 for i in range(N)] for j in range(N)]
        fixed_temporal_masks = [[1 if i == 0 and j == N - 1 else 0 for i in range(N)] for j in range(N)]
    elif mode == "Debate":
        fixed_spatial_masks = [[0 for _ in range(N)] for _ in range(N)]
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode == "Layered":
        fixed_spatial_masks = generate_layered_graph(N)
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode == "Mesh":
        fixed_spatial_masks = generate_mesh_graph(N)
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    elif mode == "Star":
        fixed_spatial_masks = generate_star_graph(N)
        fixed_temporal_masks = [[1 for _ in range(N)] for _ in range(N)]
    else:
        raise ValueError(f"Unknown mode: {mode}")

    return {
        "initial_spatial_probability": initial_spatial_probability,
        "fixed_spatial_masks": fixed_spatial_masks,
        "initial_temporal_probability": initial_temporal_probability,
        "fixed_temporal_masks": fixed_temporal_masks,
        "node_kwargs": node_kwargs,
    }


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", type=str, default="FullConnected")
    parser.add_argument("--llm_name", type=str, default="gpt-4.1-nano")
    parser.add_argument("--decision_method", type=str, default="FinalRefer")
    parser.add_argument("--domain", type=str, default="mmlu")
    parser.add_argument("--num_rounds", type=int, default=1)
    parser.add_argument("--k", type=int, default=5)  # sample size
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--max_concurrency", type=int, default=5)
    parser.add_argument("--use_baseline", action="store_true")
    args = parser.parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)

    # === same as run_mmlu.py: download(); dataset_train=MMLUDataset('test') :contentReference[oaicite:3]{index=3}
    download()
    dataset_test = MMLUDataset("test")

    # graph init: Graph(domain, llm_name, agent_names, decision_method, **kwargs) :contentReference[oaicite:4]{index=4}
    agent_names = ["AnalyzeAgent"] * 5
    kwargs = get_kwargs(args.mode, len(agent_names))
    graph = Graph(
        domain=args.domain,
        llm_name=args.llm_name,
        agent_names=agent_names,
        decision_method=args.decision_method,
        optimized_spatial=True,
        optimized_temporal=True,
        **kwargs,
    )

    # Sanity: make sure grads can flow
    assert graph.spatial_logits.requires_grad, "graph.spatial_logits must require grad"
    assert graph.temporal_logits.requires_grad, "graph.temporal_logits must require grad"

    n = len(dataset_test)
    k = min(args.k, n)
    idxs = random.sample(range(n), k)
    print(f"Sampled {k} task indices from test set (n={n}): {idxs}")

    sem = asyncio.Semaphore(args.max_concurrency)

    # ---- rollout k tasks
    rollout_tasks = [
        asyncio.create_task(
            rollout_one_task(
                graph=graph,
                dataset=dataset_test,
                task_idx=i,
                num_rounds=args.num_rounds,
                return_abcd_probs=True,
                sem=sem,
            )
        )
        for i in idxs
    ]
    rollouts = await asyncio.gather(*rollout_tasks)

    print("\n=== Rollout results ===")
    for r in rollouts:
        # choice_prob/p_correct 可能为 0（如果 arun 没给 abcd_probs），但 correct/choice 仍然可用
        print(
            f"idx={r['idx']:5d}  choice={r['choice']}  correct={r['correct']}  "
            f"choice_prob={r['choice_prob']:.6f}  p_correct={r['p_correct']:.6f}"
        )

    # ---- one-step REINFORCE grad estimate
    grad_info = reinforce_one_step_from_rollouts(graph, rollouts, use_baseline=args.use_baseline)

    gs = grad_info["grad_spatial"]
    gt = grad_info["grad_temporal"]
    gf = grad_info["grad_flat"]

    print("\n=== One-step REINFORCE gradient ===")
    print(f"loss = {grad_info['loss']:.6f}, baseline = {grad_info['baseline']:.6f}")
    print(f"||grad_spatial|| = {gs.norm().item():.6e}")
    print(f"||grad_temporal|| = {gt.norm().item():.6e}")
    print(f"||grad_flat|| = {gf.norm().item():.6e}")

    # quick sanity checks
    all_zero = (gf.abs().max().item() == 0.0)
    print(f"grad all-zero? {all_zero}")
    print("done.")


if __name__ == "__main__":
    asyncio.run(main())
