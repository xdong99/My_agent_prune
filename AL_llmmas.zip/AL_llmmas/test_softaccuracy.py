import asyncio
import os

from AgentPrune.llm.gpt_chat import GPTChat
#from accuracy import Accuracy, SoftAccuracy  # 确保 SoftAccuracy 已经加进 accuracy.py

from experiments.accuracy import Accuracy
from experiments.SoftAccuracy import SoftAccuracy

def format_mcq(question: str, A: str, B: str, C: str, D: str) -> str:
    return (
        f"{question}\n\n"
        f"A) {A}\n"
        f"B) {B}\n"
        f"C) {C}\n"
        f"D) {D}\n"
        f"\nAnswer:"
    )


async def main():
    model_name = os.getenv("MODEL_NAME", "gpt-4o-mini")
    llm = GPTChat(model_name=model_name)

    # MMLU-style question
    question = "In Python 3, which of the following function convert a string to an int in python?"
    A = "int(x[, base])"
    B = "long(x[, base])"
    C = "float(x)"
    D = "str(x)"
    correct_answer = "A"

    messages = [
        {
            "role": "system",
            "content": (
                "I will ask you a question.\n"
                "I will also give you 4 answers enumerated as A, B, C and D.\n"
                "Only one answer out of the offered 4 is correct.\n"
                "You must choose the correct answer to the question.\n"
                "Your response must be one of the 4 letters: A, B, C or D.\n"
                "Your reply must only contain one letter and cannot have any other characters.\n"
            ),
        },
        {"role": "user", "content": format_mcq(question, A, B, C, D)},
    ]

    # Ask for dict output with abcd_probs
    out = await llm.agen(messages, return_choice_logprob=True)

    print("\n=== Model output ===")
    print("text:", repr(out.get("text")))
    print("choice:", out.get("choice"))
    print("abcd_probs:", out.get("abcd_probs"))

    # Hard accuracy (original)
    acc = Accuracy()
    acc.update(out.get("choice"), correct_answer)
    print("\n=== Accuracy (hard) ===")
    acc.print()

    # Soft accuracy (new)
    sacc = SoftAccuracy()
    sacc.update(out, correct_answer)  # pass the dict
    print("\n=== SoftAccuracy ===")
    sacc.print()

    # Also show the exact p_correct used
    p_correct = (out.get("abcd_probs") or {}).get(correct_answer, 0.0)
    print("\nUsed p_correct =", p_correct)


if __name__ == "__main__":
    asyncio.run(main())
